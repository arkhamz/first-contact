First Contact - Demo
Python project 


Overview:

First contact is a simple retro-style game created using the pygame library. The objective of the game is to destroy all aliens and obtain a highscore. The game's difficulty will increase with each level.

The game will end once you have run out of all 3 of your ships. A ship is lost when the player is hit by an alien or if an alien reaches the bottom of the screen. 


How to play:

Move your ship using the RIGHT & LEFT keyboard arrows.

Fire thermo-lasers by pressing SPACEBAR. 

Press Q at any time to exit the game.


Thanks for playing!