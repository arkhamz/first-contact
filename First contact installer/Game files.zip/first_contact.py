import first_contact_functions as ff

game_active = True
menu_active = False


while game_active:
	
	ff.run_intro()
	ff.run_menu()

