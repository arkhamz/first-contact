import pygame.font

class Button():

	def __init__(self, game_settings, screen, msg):
		"""Inititalise button attributes"""
	
		self.screen = screen
		self.screen_rect = screen.get_rect()
	
		#Set the dimensions and properties of the button
		self.width, self.height = 200, 50
		self.button_colour = (0,255,0)
		self.text_colour = (255,255,255)
		self.font = pygame.font.SysFont("calibri", 40)
	
		#Build the button's rect object and center it
		self.rect = pygame.Rect(0,0, self.width, self.height)
		self.rect.center = self.screen_rect.center
		self.rect.y += 100
		
		#Prepare the button message, convert it to image and center it
		self.prep_msg(msg)
	
	def prep_msg(self,msg):
		"""Turn message into a rendered image and center it on the button"""
		self.msg_image = self.font.render(
			msg, True, self.text_colour, self.button_colour)
		self.msg_image_rect = self.msg_image.get_rect()
		self.msg_image_rect.center = self.rect.center
	
	def draw_button(self):
		#draw blank button and draw message
		self.screen.fill(self.button_colour, self.rect)
		self.screen.blit(self.msg_image, self.msg_image_rect)

class MenuButton():

	def __init__(self, game_settings, menu):
		"""Inititalise button attributes"""
	
		self.menu = menu
		self.menu_rect = menu.get_rect()
		
		self.msg1 = "Play"
		self.msg2 = "Quit"
	
		#Set the button's dimensions and properties
		self.width, self.height = 200, 50
		self.button_colour = (65,146,121)
		self.lighter = (98,145,130)
	
		self.text_colour = (255,255,255)
		self.font = pygame.font.SysFont("calibri", 40)
		
	
	
		#Create a play button rect and center it
		#playb and exitb are button rects for play and exit buttons
		
		self.play_rect = pygame.Rect(0,0, self.width, self.height)
		self.play_rect.center = self.menu_rect.center
		#Create an exit button rect 80 pixels below play button
		self.exit_rect = pygame.Rect(0,0, self.width, self.height)
		self.exit_rect.center = self.menu_rect.center
		self.exit_rect.y += 80
		
		#Prepares the button message by rendering it as image and center
		#-ing it
		self.prep_playb("Play Game")
		self.prep_exitb("Quit Game")
	
	def prep_playb(self,msg):
		"""Convert the msg text into an image and center it on button"""
		#Create image of message text
		self.msg_image1 = self.font.render(msg,
			True, self.text_colour, self.button_colour)
		#create rect of message image
		self.msg_image_rect1 = self.msg_image1.get_rect()
		#use message image rect to center  message image on the button
		self.msg_image_rect1.center = self.play_rect.center	
	
	def prep_exitb(self,msg):
		"""Convert the msg text into an image and center it on button"""
		self.msg_image2 = self.font.render(
			msg, True, self.text_colour, self.button_colour)
		self.msg_image_rect2 = self.msg_image2.get_rect()
		self.msg_image_rect2.center = self.exit_rect.center	
		
	

	def draw_button(self):
		#draw green button via fill and draw message via blit
		self.menu.fill(self.button_colour, self.play_rect)
		self.menu.fill(self.button_colour, self.exit_rect)
		self.menu.blit(self.msg_image1, self.msg_image_rect1)
		self.menu.blit(self.msg_image2,self.msg_image_rect2)
		
		mouse_x,mouse_y = pygame.mouse.get_pos()
		#change button colour if mouse is over button
		if self.play_rect.collidepoint(mouse_x,mouse_y):
		
			self.menu.fill(self.lighter, self.play_rect)
			self.menu.blit(self.msg_image1, self.msg_image_rect1)
			
		if self.exit_rect.collidepoint(mouse_x,mouse_y):
			self.menu.fill(self.lighter, self.exit_rect)
			self.menu.blit(self.msg_image2,self.msg_image_rect2)
