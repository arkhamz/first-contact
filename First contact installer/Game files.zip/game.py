import sys
import pygame

from pygame.sprite import Group
from settings import Settings
from ship import Ship
from game_stats import GameStats
from button import Button
from scoreboard import Scoreboard

import game_functions as gf

def run_game():
	#Initialise the game and create a screen object.
	pygame.init()
	
	#Play background music
	#pygame.mixer.music.load("bg_music.wav")
	#pygame.mixer.music.play(-1)
	
	game_settings = Settings()
	screen = pygame.display.set_mode((
	game_settings.screen_width, game_settings.screen_height))
		#Add pygame.FULLSCREEN arg after tuple to make it fulscreen
	pygame.display.set_caption("First contact")
	
	#screen2 = pygame.display.set_mode((
	#game_settings.screen_width, game_settings.screen_height))
	#pygame.display.set_caption("First contact")

	
	clock = pygame.time.Clock()

	
	#Make the play button
	play_button = Button(game_settings,screen,"Start")
	
	#Make a GameStats instance and a scoreboard instance
	stats = GameStats(game_settings)
	score = Scoreboard(game_settings,screen,stats)
	
	#make a ship, bullet group and alien group
	ship = Ship(game_settings, screen)
	bullets = Group()
	aliens = Group()

	#create the fleet of aliens
	gf.create_fleet(game_settings, screen,ship, aliens)

	#Start the main loop for the game.
	while True:
		gf.check_events(game_settings,screen,stats,score,play_button,
			ship,aliens,bullets)
		
		if stats.game_active:
			ship.update()
			gf.update_bullets(game_settings,screen,stats,score,ship,
				aliens,bullets)
			gf.update_aliens(game_settings,screen,stats,score,ship,
				aliens,bullets)
				
			clock.tick(500)
		
			
		gf.update_screen(game_settings, screen,stats,score,ship,aliens,
			bullets,play_button)
		

#run_game()

