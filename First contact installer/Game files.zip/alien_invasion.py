import sys

import pygame

from settings import Settings

from ship import Ship

def run_game():
	#Initialise the game and create a screen object.
	pygame.init()
	game_settings = Settings()
	screen = pygame.display.set_mode((
	game_settings.screen_width, game_settings.screen_height))
	pygame.display.set_caption("Alien Invasion")
	
	ship = Ship(screen)
	
	#Start the main loop for the game.
	while True:
		
		#watch for keyboard and mouse events.
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				sys.exit()
		
		#Redraw screen during each pass through loop
		screen.fill(game_settings.bg_colour)
		ship.blitme()
		
		#make the most recently drawn screen visible
		pygame.display.flip()

run_game()

#We first imported the sys and pygame modules.
#Pygame module contains the tools needed to make a game.
#We use the sys module to exit the game when the player quiets

